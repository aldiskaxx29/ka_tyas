<?php
function check_role($role_id)
{
    $roles = ['' . 'admin', 'calon_siswa', 'siswa'];
}

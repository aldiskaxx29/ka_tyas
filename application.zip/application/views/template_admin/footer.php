<footer class="main-footer">
  <div class="footer-left">
    Copyright &copy; 2018 <div class="bullet"></div> Design By <a href="https://nauval.in/">Muhamad Nauval Azhar</a>
  </div>
  <div class="footer-right">
    2.3.0
  </div>
</footer>
</div>
</div>

<div id="modalFoto" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <img src="" alt="Foto Bukti" id="fotoBukti" width="100%">
      </div>
    </div>
  </div>
</div>

<!-- General JS Scripts -->
<script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.nicescroll/3.7.6/jquery.nicescroll.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
<script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets/') ?>assets/js/stisla.js"></script>

<!-- JS Libraies -->
<!-- https://code.jquery.com/jquery-3.5.1.js -->
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>


<!-- https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js -->
<!-- https://cdn.datatables.net/responsive/2.2.9/js/responsive.bootstrap4.min.js -->

<!-- Template JS File -->
<script src="<?= base_url('assets/') ?>assets/js/scripts.js"></script>
<script src="<?= base_url('assets/') ?>assets/js/custom.js"></script>

<!-- Page Specific JS File -->
<script>
  $(document).ready(function() {
    $('#myTable').DataTable();

    $('.foto-bukti img').click(function(e) {
      e.preventDefault()
      let srcImg = $(this).attr('src')
      console.log(srcImg)
      $('#fotoBukti').attr('src', srcImg)
      $('#modalFoto').modal('show')
    })

    $('#tahun').change(function(e) {
      $('#formFilterTahun').submit()
    })
  });
</script>
</body>

</html>